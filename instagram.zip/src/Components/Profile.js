import React, { useState } from 'react'
import Slider from './Slider'

function Profile() {
  return (
    <div className='flex'>
    <Slider></Slider>
   <div className="w-[95%] z-50 flex flex-col items-center h-[100vh] bg-[white] top-0 left-[15%] fixed border-left border-[2px] border-gray-200 ">
      <div className="w-[70%] h-[30vh] flex  pt-12 ">
        <div className="w-[25%] ">
          <img className="w-[140px] h-[140px] rounded-full" src= "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwVAB6X0ZDV0j3ttURoBIyD-KQZlNNaLecA0R-m3ufDDtRUgPxvOpVSwrccNE8pXI5L5I&usqp=CAU"></img>
        </div>
        <div className="w-[60%] flex flex-col  gap-4">
          <div className="w-[100%] flex gap-4 items-center">
            <label className="text-[18px] font-medium">dipika-001</label>
            <div className="w-[23%] h-[5vh] bg-gray-300 rounded-md flex items-center justify-center border text-[14px] font-semibold">Edit profile</div>

            <div className="w-[24%] h-[5vh] bg-gray-300 rounded-md flex items-center justify-center border text-[14px] font-semibold">View archive</div>
            <i class="fa fa-sun-o text-[25px]" aria-hidden="true"></i>
             </div>
             <div className="w-[60%] flex justify-between">
              <label><span className="font-semibold">0</span> posts</label>
              <label><span className="font-semibold">0</span> followers</label>
              <label><span className="font-semibold">0</span> following</label>
             </div>
             <div className="flex flex-col">
              <label className='font-semibold'>DIPIKA</label>
             </div>
             </div>
      </div>
      <div className="w-[70%] h-[25vh] flex items-center gap-7 ">
        <div className="flex items-center justify-center flex-col  ">
        <div className="w-[80px] h-[80px] rounded-full border bg-yellow-100"></div>
        <label>.</label>
        </div>

        <div className="flex items-center justify-center flex-col ">
        <div className="w-[80px] h-[80px] rounded-full border  bg-yellow-100"></div>
        <label>.</label>
        </div>

        <div className="flex items-center justify-center flex-col ">
        <div className="w-[80px] h-[80px] rounded-full border  bg-yellow-100"></div>
        <label>.</label>
        </div>

        <div className="flex items-center justify-center flex-col ">
        <div className="w-[80px] h-[80px] rounded-full border  bg-yellow-100"></div>
        <label>.</label>
        </div>

        <div className="flex flex-col items-center justify-center gap-1">
        <div className="w-[80px] h-[80px] rounded-full border flex items-center justify-center">
          <label className="text-[40px] text-gray-400 ">+</label>
        </div>
        <label className="text-[13px] font-semibold">.</label>
         </div>

      </div>

     </div>
    </div>
  )
}

export default Profile