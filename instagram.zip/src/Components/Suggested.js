import React from 'react'
import FollowData from "../api/follow.json";

function Suggested() {
  return (
    <div className='h-[60vh] w-[25%] pt-[50px] flex flex-col gap-3'>
    <div className='h-[7vh] w-[100%]  flex justify-between px-4'>
    <div className='w-[50%] h-[8vh] flex items-center gap-2 '>
    <img className='w-[45px] h-[45px] border-[2px] rounded-full ' src='https://marketplace.canva.com/EAFuKNWv9mg/2/0/1600w/canva-purple-and-yellow-colorful-woman-instagram-profile-picture-lvrGx6QJohg.jpg'></img>
    <div className='flex flex-col'>
      <label className='font-semibold'>{localStorage.getItem("username")}</label>
      <label className='text-gray-500'>DEEPIKA</label>
    </div>
    </div>
    <div className='w-[50%] h-[7vh] flex justify-end  items-center'>
    <label className='text-[14px] text-blue-600 font-semibold hover:text-gray-500'>switch</label>
    </div>
    </div>
    <div className='w-[100%] h-[6vh] px-4 flex justify-between items-center'>
    <label className='font-semibold text-[15px] text-gray-500'>Suggested for you</label>
    <label className='text-[15px]'>See All</label>
    </div>
     {FollowData.map((i)=>
    <div className='h-[8vh] w-[100%]  flex   justify-between px-4'>
    <div className='w-[50%] h-[7vh] flex items-center gap-3 '>
    <img className='w-[45px] h-[45px] border-[2px] rounded-full 'src={i.dp}></img>
    <div className='flex flex-col '>
      <label className='font-semibold'>{i.username}</label>
      <label className='text-gray-500 text-[12px]'>Suggested for you</label>
    </div>
    </div>
   <div className='w-[50%] h-[7vh] flex justify-end  items-center'>
    <label className='text-[13px] text-blue-500 font-semibold hover:text-gray-500'>Follow</label>
    </div>
    </div>
     )}
    <div className=' h-[7vh] w-[95%]  text-[13px] flex gap-1 flex-wrap pl-[30px]'>
    <button className=' text-gray-400 hover:underline'>About.</button>
    <button className=' text-gray-400 hover:underline'>Help.</button>
    <button className=' text-gray-400 hover:underline'>Press.</button>
    <button className=' text-gray-400 hover:underline'>API.</button>
    <button className=' text-gray-400 hover:underline'>Jobs.</button>
    <button className=' text-gray-400 hover:underline'>Privacy.</button>
    <button className=' text-gray-400 hover:underline'>Terms.</button>
    <button className=' text-gray-400 hover:underline'>Locations.</button>
    <button className=' text-gray-400 hover:underline'>Language.</button>
    <button className=' text-gray-400 hover:underline'>Meta Verified</button>
    </div>
    <label className='text-[13px] text-gray-400 pl-[30px]'>© 2024 INSTAGRAM FROM META</label>
   </div>
  )
}

export default Suggested