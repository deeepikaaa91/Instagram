import React from "react";
import Slider from "../Components/Slider";
import Suggested from "../Components/Suggested";
import StoryData from "../api/story.json";

function HomePage() {
  return (
    <div className="flex ">
      <Slider />
      <div className="h-[190vh]  w-[50%] border-[2px] border-solid flex flex-col   text-[12px] gap-2  justify-center items-center ">
        <div className="  w-[100%] flex gap-3 justify-center items-center">
          {StoryData.map((i)=>
          <div className="flex flex-col items-center gap-1 w-[70px] rounded-[50px]  ">
            <img
              className="h-[70px] w-[70px] rounded-[50px] object-cover object-center border-[2px] border-solid border-red-400 "
              src={i.dp}
            ></img>
            <label>{i.username} </label>
          </div>
        
        )}
        </div>

        <div className="h-[80vh]  w-[60%] flex flex-col  gap-2">
          <div className="h-[7vh] w-[100%]  flex  pl-[10px] items-center justify-between ">
            <div className="h-[5vh] w-[100%] flex items-center justify-between">
              <div className="h-[40px] w-[40px]  rounded-[50px]  flex items-center gap-1  ">
                <img
                  className="h-[40px] w-[40px] rounded-[50px] object-cover object-center border-[2px]  border-red-300 "
                  src="https://images.ctfassets.net/hrltx12pl8hq/28ECAQiPJZ78hxatLTa7Ts/2f695d869736ae3b0de3e56ceaca3958/free-nature-images.jpg?fit=fill&w=1200&h=630"
                ></img>
                <h1 className="font-bold text-[12px]">Nature</h1>
                <label className="font-bold text-[15px] text-gray-400">.</label>
                <label className="font-bold text-[12px] text-gray-400">
                  6h
                </label>
              </div>

              <div className="flex h-[2vh] w-[10%] gap-1 justify-center items-center  ">
                <div className="h-[4px] w-[4px] bg-black rounded-[50px]"></div>
                <div className="h-[4px] w-[4px] bg-black rounded-[50px]"></div>
                <div className="h-[4px] w-[4px] bg-black rounded-[50px]"></div>
              </div>
            </div>
          </div>
          <img
            className="h-[70vh] w-[100%] object-cover object-center rounded-[5px]"
            src="https://st2.depositphotos.com/1000152/8596/i/450/depositphotos_85962280-stock-photo-autumn-forest-trees.jpg"
          ></img>

          <div className="h-[7vh] w-[1005]  flex  justify-between">
            <div className="h-[7vh] w-[25%] flex items-center gap-2 pl-[10px]">
              <i class="fa fa-heart-o fa-2x" aria-hidden="true"></i>
              <i class="fa fa-comment-o fa-2x" aria-hidden="true"></i>
              <i class="fa fa-share-alt fa-2x" aria-hidden="true"></i>
            </div>
            <div className="h-[7vh] w-[10%]   flex items-center">
              <i class="fa fa-bookmark-o fa-2x" aria-hidden="true"></i>
            </div>
          </div>
          <div className="h-[10vh] w-[100%]  flex flex-col ">
            <label className="font-bold text-[14px]">28,670 likes</label>
            <label className=" font-medium text-gray-400 text-[12px]">
              This view never gets old.
            </label>
            <label className=" font-thin text-gray-400 text-[12px]">
              view all 650 comments
            </label>
            <label className=" font-light text-gray-400">
              {" "}
              Add a Comment.....
            </label>
          </div>

          <div className="h-[1px] w-[100%] bg-gray-500"></div>
        </div>

        <div className="h-[4vh] w-[60%]  flex justify-between">
          <div className="h-[4vh] w-[25%]  flex items-center">
            <label className="text-[14px]">Suggested for you</label>
          </div>
          <div className="h-[4vh] w-[10%] flex items-center">
            <i class="fa fa-times fa-lg" aria-hidden="true"></i>
          </div>
        </div>

        <div className="h-[80vh] w-[60%] flex flex-col  gap-1">
          <div className="h-[7vh] w-[100%]  flex  pl-[10px] items-center justify-between">
            <div className="h-[5vh] w-[100%] flex items-center justify-between">
              <div className="h-[40px] w-[40px]  rounded-[50px]  flex items-center gap-1  ">
                <img
                  className="h-[40px] w-[40px] rounded-[50px] object-cover object-center border-[2px]  border-red-300 "
                  src="https://florette.ae/cdn/shop/collections/Screen_Shot_2022-04-30_at_5.15.56_PM_814x796.png?v=1696050634"
                ></img>
                <h1 className="font-bold text-[12px]">Flower</h1>
                <label className="font-bold text-[15px] text-gray-400">.</label>
                <label className="font-bold text-[12px] text-gray-400">
                  10h
                </label>
              </div>

              <div className="flex h-[2vh] w-[10%] gap-1 justify-center items-center  ">
                <div className="h-[4px] w-[4px] bg-black rounded-[50px]"></div>
                <div className="h-[4px] w-[4px] bg-black rounded-[50px]"></div>
                <div className="h-[4px] w-[4px] bg-black rounded-[50px]"></div>
              </div>
            </div>
          </div>
          <img
            className="h-[70vh] w-[100%] object-cover object-center rounded-[5px]"
            src="https://hips.hearstapps.com/hmg-prod/images/pink-lotus-flowers-and-leaves-in-the-lake-royalty-free-image-1686761539.jpg"
          ></img>

          <div className="h-[7vh] w-[1005]  flex  justify-between">
            <div className="h-[7vh] w-[25%] flex items-center gap-2 pl-[10px]">
              <i class="fa fa-heart-o fa-2x" aria-hidden="true"></i>
              <i class="fa fa-comment-o fa-2x" aria-hidden="true"></i>
              <i class="fa fa-share-alt fa-2x" aria-hidden="true"></i>
            </div>
            <div className="h-[7vh] w-[10%]   flex items-center">
              <i class="fa fa-bookmark-o fa-2x" aria-hidden="true"></i>
            </div>
          </div>
          <div className="h-[10vh] w-[100%]  flex flex-col ">
            <label className="font-bold text-[14px]">20,5706 likes</label>
            <label className=" font-medium text-gray-400 text-[12px]">
              Blossom by blossom, the garden reveals its secrets. 🌸
            </label>
            <label className=" font-thin text-gray-400 text-[12px]">
              view all 650 comments
            </label>
            <label className=" font-light text-gray-400">
              {" "}
              Add a Comment.....
            </label>
          </div>

          <div className="h-[1px] w-[100%] bg-gray-500"></div>
        </div>
      </div>
      <Suggested />
      </div>
  );
}

export default HomePage;
