const mongoose = require("mongoose")

const UserDetailSchema = mongoose.Schema({
    username: String,
    password: String,
    mobile  : Number,
    fullName: String,
    post:[
        {
            image:String,
            likes:Array,
            comment:Array,
            share:Array,
            caption:String
        }
    ]

    })

module.exports = mongoose.model("UserDetail", UserDetailSchema);
